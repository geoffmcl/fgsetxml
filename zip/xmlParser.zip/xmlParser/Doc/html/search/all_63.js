var searchData=
[
  ['char_5fencoding_5fbig5',['char_encoding_Big5',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2abf8658aa97c3bcb0d714cce6bb77a0b8',1,'XMLNode']]],
  ['char_5fencoding_5ferror',['char_encoding_error',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2a901e3af8a5e1308d1a198398c2b3da76',1,'XMLNode']]],
  ['char_5fencoding_5fgb2312',['char_encoding_GB2312',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2a6f2ed679397fa246d1e5062371ba3776',1,'XMLNode']]],
  ['char_5fencoding_5fgbk',['char_encoding_GBK',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2a5f55b2ae64719235ea4ea4aae651264c',1,'XMLNode']]],
  ['char_5fencoding_5flegacy',['char_encoding_legacy',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2afcce4646efba5d15cc00d958a075c1ed',1,'XMLNode']]],
  ['char_5fencoding_5fshiftjis',['char_encoding_ShiftJIS',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2afa21f31e866cedff460f7e907d2339cc',1,'XMLNode']]],
  ['char_5fencoding_5futf8',['char_encoding_UTF8',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2a0b35b4d55aae2d232400578ab1123d5a',1,'XMLNode']]],
  ['child',['child',['../structXMLNodeContents.html#a07bfee26b5b5c9e15adcb172f3b7f846',1,'XMLNodeContents']]],
  ['clear',['clear',['../structXMLNodeContents.html#a08ef8b489dd008060a1ff28269c6730e',1,'XMLNodeContents']]],
  ['createxmlstring',['createXMLString',['../group__conversions.html#gac8710ba5e7ff6e62a222445501ef9972',1,'XMLNode']]],
  ['createxmltopnode',['createXMLTopNode',['../group__creation.html#ga1e2d0403450db891eedc76b6bfdba452',1,'XMLNode']]],
  ['createxmltopnode_5fwosd',['createXMLTopNode_WOSD',['../group__xmlWOSD.html#ga9c8b3bfa9671cb2a0a977ef30bab364a',1,'XMLNode']]],
  ['creating_20from_20scratch_20a_20xmlnode_20structure',['Creating from scratch a XMLNode structure',['../group__creation.html',1,'']]],
  ['create_20or_20update_20the_20xmlnode_20structure',['Create or Update the XMLNode structure',['../group__xmlModify.html',1,'']]]
];
