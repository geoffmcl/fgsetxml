var searchData=
[
  ['openfilehelper',['openFileHelper',['../group__conversions.html#ga46f99cf406604471e15d4378f74ecc63',1,'XMLNode']]],
  ['operator_3d',['operator=',['../structXMLNode.html#a8154edc759dc934043803de2521c056c',1,'XMLNode']]]
];
