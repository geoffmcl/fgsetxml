var searchData=
[
  ['decode',['decode',['../structXMLParserBase64Tool.html#aace2e0d4ee4ef24890cfeb5c67d5a58a',1,'XMLParserBase64Tool::decode(XMLCSTR inString, int *outByteLen=NULL, XMLError *xe=NULL)'],['../structXMLParserBase64Tool.html#af76fe76cb08f0a3fca6d7352c0dcb218',1,'XMLParserBase64Tool::decode(XMLCSTR inString, unsigned char *outByteBuf, int inMaxByteOutBuflen, XMLError *xe=NULL)']]],
  ['decodesize',['decodeSize',['../structXMLParserBase64Tool.html#adce9ee3c0bc1cae2ab2b511add3ea91e',1,'XMLParserBase64Tool']]],
  ['deepcopy',['deepCopy',['../group__navigate.html#gadb69f8d2db5997d84590ce3380e210f1',1,'XMLNode']]],
  ['deleteattribute',['deleteAttribute',['../group__xmlDelete.html#ga61b2405305063594b35b309cc2e22c01',1,'XMLNode::deleteAttribute(int i=0)'],['../group__xmlDelete.html#ga2b21339e5b370f1d7ebde2dc51217eed',1,'XMLNode::deleteAttribute(XMLCSTR lpszName)'],['../group__xmlDelete.html#ga6f00d7c1b4eaa29cfdd9d4a709495aca',1,'XMLNode::deleteAttribute(XMLAttribute *anAttribute)']]],
  ['deleteclear',['deleteClear',['../group__xmlDelete.html#ga44b72c82310eb4319dba46eb9cc9f6e9',1,'XMLNode::deleteClear(int i=0)'],['../group__xmlDelete.html#ga8fff4baa9a8000f8662ee302438fff64',1,'XMLNode::deleteClear(XMLCSTR lpszValue)'],['../group__xmlDelete.html#gae92182823d3d5b40893103ad222ec4a8',1,'XMLNode::deleteClear(XMLClear *p)']]],
  ['deletenodecontent',['deleteNodeContent',['../group__xmlDelete.html#gaa4d133999da220e916bdf3a969d493c4',1,'XMLNode']]],
  ['deletetext',['deleteText',['../group__xmlDelete.html#ga14a49a23735ea10a44864cb6b4302250',1,'XMLNode::deleteText(int i=0)'],['../group__xmlDelete.html#ga21ee499630d71ab6026753a85f02f582',1,'XMLNode::deleteText(XMLCSTR lpszValue)']]],
  ['deleting_20nodes_20or_20attributes',['Deleting Nodes or Attributes',['../group__xmlDelete.html',1,'']]]
];
