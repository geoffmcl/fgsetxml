var searchData=
[
  ['parsing_20xml_20files_2fstrings_20to_20an_20xmlnode_20structure_20and_20rendering_20xmlnode_27s_20to_20files_2fstring_2e',['Parsing XML files/strings to an XMLNode structure and Rendering XMLNode&apos;s to files/string.',['../group__conversions.html',1,'']]],
  ['parsefile',['parseFile',['../group__conversions.html#gae984d7ebce97fad429b2b786439815fb',1,'XMLNode']]],
  ['parsestring',['parseString',['../group__conversions.html#ga72125a4ccfae9b39bafab768346bbc7e',1,'XMLNode']]],
  ['positionofchildnode',['positionOfChildNode',['../group__xmlPosition.html#gac98af1de6ed1218e5d26f7e509b8678f',1,'XMLNode::positionOfChildNode(int i=0) const '],['../group__xmlPosition.html#gaf8457366bc393a57e33896e46592cb3e',1,'XMLNode::positionOfChildNode(XMLNode x) const '],['../group__xmlPosition.html#ga102dcd93d13144e2a87b664e6f810725',1,'XMLNode::positionOfChildNode(XMLCSTR name, int i=0) const ']]],
  ['positionofclear',['positionOfClear',['../group__xmlPosition.html#gafbeb4c6fcb5f164a4e5501d048c0f714',1,'XMLNode::positionOfClear(int i=0) const '],['../group__xmlPosition.html#gaae9a760878f7e2d8e392b17edb00ea19',1,'XMLNode::positionOfClear(XMLCSTR lpszValue) const '],['../group__xmlPosition.html#ga917818941aa305d3829472d49f33a4b5',1,'XMLNode::positionOfClear(XMLClear *a) const ']]],
  ['positionoftext',['positionOfText',['../group__xmlPosition.html#ga4376524698201e37c805bfa37945a600',1,'XMLNode::positionOfText(int i=0) const '],['../group__xmlPosition.html#ga3a590db071ce9f3fdc6e82405ab8507d',1,'XMLNode::positionOfText(XMLCSTR lpszValue) const ']]],
  ['position_20helper_20functions_20_28use_20in_20conjunction_20with_20the_20update_26add_20functions',['Position helper functions (use in conjunction with the update&amp;add functions',['../group__xmlPosition.html',1,'']]]
];
