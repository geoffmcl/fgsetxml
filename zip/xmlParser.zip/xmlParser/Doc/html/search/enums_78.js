var searchData=
[
  ['xmlcharencoding',['XMLCharEncoding',['../structXMLNode.html#a81bcd09f9c752b65633c1ca28ea025f2',1,'XMLNode']]],
  ['xmlelementtype',['XMLElementType',['../xmlParser_8h.html#a100a496e2b573b37eb4e75f00a316851',1,'xmlParser.h']]],
  ['xmlerror',['XMLError',['../xmlParser_8h.html#ac39bd07b1461aaa70afffe2d7162b4f5',1,'xmlParser.h']]]
];
