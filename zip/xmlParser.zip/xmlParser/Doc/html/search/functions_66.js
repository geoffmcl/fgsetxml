var searchData=
[
  ['freebuffer',['freeBuffer',['../structToXMLStringTool.html#a0572044b9caffb4436b48c7b380fc70f',1,'ToXMLStringTool::freeBuffer()'],['../structXMLParserBase64Tool.html#a3d9e7dcbe313eef25a324b88667f4c65',1,'XMLParserBase64Tool::freeBuffer()']]],
  ['freexmlstring',['freeXMLString',['../group__StringAlloc.html#ga6a510c9553d7fa49d0afdda1d7928669',1,'xmlParser.h']]]
];
