var searchData=
[
  ['lpszclosetag',['lpszCloseTag',['../structXMLClear.html#a28c30d46f2965cfdea9dcd7ff10e0386',1,'XMLClear']]],
  ['lpszname',['lpszName',['../structXMLAttribute.html#a59d24e06998261f56a5b8e2f2b20ea9e',1,'XMLAttribute']]],
  ['lpszopentag',['lpszOpenTag',['../structXMLClear.html#a2df4ad4786cc0d3f7eae94607a02f6e3',1,'XMLClear']]],
  ['lpszvalue',['lpszValue',['../structXMLClear.html#a72d26ba6f77bdfc5fdaf0e0802d8809e',1,'XMLClear::lpszValue()'],['../structXMLAttribute.html#a2e1317aefc63d17247e3e12091b90618',1,'XMLAttribute::lpszValue()']]]
];
