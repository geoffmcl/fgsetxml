var searchData=
[
  ['navigate_20the_20xmlnode_20structure',['Navigate the XMLNode structure',['../group__navigate.html',1,'']]]
];
