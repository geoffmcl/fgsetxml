var searchData=
[
  ['createxmlstring',['createXMLString',['../group__conversions.html#gac8710ba5e7ff6e62a222445501ef9972',1,'XMLNode']]],
  ['createxmltopnode',['createXMLTopNode',['../group__creation.html#ga1e2d0403450db891eedc76b6bfdba452',1,'XMLNode']]],
  ['createxmltopnode_5fwosd',['createXMLTopNode_WOSD',['../group__xmlWOSD.html#ga9c8b3bfa9671cb2a0a977ef30bab364a',1,'XMLNode']]]
];
