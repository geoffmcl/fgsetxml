var searchData=
[
  ['nattribute',['nAttribute',['../group__navigate.html#ga9561f62b9ed1fa653fe9135c4f16a41d',1,'XMLNode']]],
  ['nchildnode',['nChildNode',['../group__navigate.html#ga8e52198f258167cd796dae21f1ffc352',1,'XMLNode::nChildNode(XMLCSTR name) const '],['../group__navigate.html#ga65aad0220b231b1bf5cd5c69d7c5de41',1,'XMLNode::nChildNode() const ']]],
  ['nclear',['nClear',['../group__navigate.html#ga87d34f1ba1ba7d49e8aeacc63548dead',1,'XMLNode']]],
  ['nelement',['nElement',['../group__navigate.html#ga8e9538deb9144dcab39b3a510a8202f1',1,'XMLNode']]],
  ['ntext',['nText',['../group__navigate.html#ga22e7e7cf8f173a1ec3ec3d6ff60819d9',1,'XMLNode']]]
];
