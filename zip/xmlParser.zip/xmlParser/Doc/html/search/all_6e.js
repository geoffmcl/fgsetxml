var searchData=
[
  ['nattribute',['nAttribute',['../group__navigate.html#ga9561f62b9ed1fa653fe9135c4f16a41d',1,'XMLNode']]],
  ['navigate_20the_20xmlnode_20structure',['Navigate the XMLNode structure',['../group__navigate.html',1,'']]],
  ['nchildnode',['nChildNode',['../group__navigate.html#ga8e52198f258167cd796dae21f1ffc352',1,'XMLNode::nChildNode(XMLCSTR name) const '],['../group__navigate.html#ga65aad0220b231b1bf5cd5c69d7c5de41',1,'XMLNode::nChildNode() const ']]],
  ['nclear',['nClear',['../group__navigate.html#ga87d34f1ba1ba7d49e8aeacc63548dead',1,'XMLNode']]],
  ['ncolumn',['nColumn',['../structXMLResults.html#af0d1358dbb7b124d2e8e4d9052509c8e',1,'XMLResults']]],
  ['nelement',['nElement',['../group__navigate.html#ga8e9538deb9144dcab39b3a510a8202f1',1,'XMLNode']]],
  ['nline',['nLine',['../structXMLResults.html#a8741d887c2843fc1ce8fffc12f662595',1,'XMLResults']]],
  ['ntext',['nText',['../group__navigate.html#ga22e7e7cf8f173a1ec3ec3d6ff60819d9',1,'XMLNode']]]
];
