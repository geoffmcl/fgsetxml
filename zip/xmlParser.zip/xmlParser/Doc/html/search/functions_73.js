var searchData=
[
  ['setglobaloptions',['setGlobalOptions',['../group__conversions.html#ga2e3943ac932bf3e786810234e7c295b9',1,'XMLNode']]],
  ['stringdup',['stringDup',['../group__StringAlloc.html#gac35b3be05a320f835b3976179637fe76',1,'xmlParser.h']]]
];
