var searchData=
[
  ['deleting_20nodes_20or_20attributes',['Deleting Nodes or Attributes',['../group__xmlDelete.html',1,'']]]
];
