var searchData=
[
  ['text',['text',['../structXMLNodeContents.html#a9e3eda44aa3b88d61cbfbe8d5b055c51',1,'XMLNodeContents']]]
];
