var searchData=
[
  ['attrib',['attrib',['../structXMLNodeContents.html#a0fd3093b1eac5edcb67bec9cf40cdaac',1,'XMLNodeContents']]]
];
