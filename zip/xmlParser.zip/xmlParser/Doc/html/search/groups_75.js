var searchData=
[
  ['updating_20nodes',['Updating Nodes',['../group__xmlUpdate.html',1,'']]]
];
