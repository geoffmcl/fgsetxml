var searchData=
[
  ['child',['child',['../structXMLNodeContents.html#a07bfee26b5b5c9e15adcb172f3b7f846',1,'XMLNodeContents']]],
  ['clear',['clear',['../structXMLNodeContents.html#a08ef8b489dd008060a1ff28269c6730e',1,'XMLNodeContents']]]
];
