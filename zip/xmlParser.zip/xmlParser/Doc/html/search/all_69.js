var searchData=
[
  ['isattributeset',['isAttributeSet',['../group__navigate.html#ga8059888e8dd5d9caf04f765059c1b934',1,'XMLNode']]],
  ['isdeclaration',['isDeclaration',['../group__navigate.html#ga71df27d54a2dc09b0a456406a7e8c6d3',1,'XMLNode']]],
  ['isempty',['isEmpty',['../group__navigate.html#ga764ce0ff117af3e30ab0959114d36f9c',1,'XMLNode']]]
];
