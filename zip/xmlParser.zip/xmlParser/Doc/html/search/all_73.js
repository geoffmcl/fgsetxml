var searchData=
[
  ['setglobaloptions',['setGlobalOptions',['../group__conversions.html#ga2e3943ac932bf3e786810234e7c295b9',1,'XMLNode']]],
  ['string_20allocation_2ffree_20functions',['String Allocation/Free functions',['../group__StringAlloc.html',1,'']]],
  ['stringdup',['stringDup',['../group__StringAlloc.html#gac35b3be05a320f835b3976179637fe76',1,'xmlParser.h']]]
];
