var searchData=
[
  ['helper_20class_20to_20create_20xml_20files_20using_20_22printf_22_2c_20_22fprintf_22_2c_20_22cout_22_2c_2e_2e_2e_20functions_2e',['Helper class to create XML files using &quot;printf&quot;, &quot;fprintf&quot;, &quot;cout&quot;,... functions.',['../group__ToXMLStringTool.html',1,'']]],
  ['helper_20class_20to_20include_20binary_20data_20inside_20xml_20strings_20using_20_22base64_20encoding_22_2e',['Helper class to include binary data inside XML strings using &quot;Base64 encoding&quot;.',['../group__XMLParserBase64Tool.html',1,'']]]
];
