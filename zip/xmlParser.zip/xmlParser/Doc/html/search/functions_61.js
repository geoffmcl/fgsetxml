var searchData=
[
  ['addattribute',['addAttribute',['../group__creation.html#ga4f0e996a36cdda88b76bdf49d0d2e50c',1,'XMLNode']]],
  ['addattribute_5fwosd',['addAttribute_WOSD',['../group__xmlWOSD.html#ga653039c9f5fb22076a00b258284c65ee',1,'XMLNode']]],
  ['addchild',['addChild',['../group__creation.html#ga51baa56a48f69cdea6f41ed38a2cbadd',1,'XMLNode::addChild(XMLCSTR lpszName, char isDeclaration=FALSE, XMLElementPosition pos=-1)'],['../group__creation.html#ga37c862f1d4a86f95417f97ceaa40d0fa',1,'XMLNode::addChild(XMLNode nodeToAdd, XMLElementPosition pos=-1)']]],
  ['addchild_5fwosd',['addChild_WOSD',['../group__xmlWOSD.html#ga24b13602fdff0194b087df4eaf28e703',1,'XMLNode']]],
  ['addclear',['addClear',['../group__creation.html#gafb513cd0d881bcb153d702a885aebc44',1,'XMLNode']]],
  ['addclear_5fwosd',['addClear_WOSD',['../group__xmlWOSD.html#ga6d3ed8368db156df576e0c54f5f45d30',1,'XMLNode']]],
  ['addtext',['addText',['../group__creation.html#ga1de718e237befa215381d294fc644f11',1,'XMLNode']]],
  ['addtext_5fwosd',['addText_WOSD',['../group__xmlWOSD.html#ga90944eacfeb994486e3ca83a68c35b6a',1,'XMLNode']]]
];
