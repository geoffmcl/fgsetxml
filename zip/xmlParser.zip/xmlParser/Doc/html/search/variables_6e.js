var searchData=
[
  ['ncolumn',['nColumn',['../structXMLResults.html#af0d1358dbb7b124d2e8e4d9052509c8e',1,'XMLResults']]],
  ['nline',['nLine',['../structXMLResults.html#a8741d887c2843fc1ce8fffc12f662595',1,'XMLResults']]]
];
