var searchData=
[
  ['the_20xml_20parser',['The XML parser',['../group__XMLParserGeneral.html',1,'']]]
];
